package VAIO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Software;
import dao.SoftwareDAO;


public class A extends HttpServlet {


	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		String fullname=request.getParameter("fullname").trim();
		String info=request.getParameter("email").trim();
		
		SoftwareDAO so=new SoftwareDAO();
		Software soft=new Software();
		soft.setDate(new Date(0));
		soft.setName(fullname);
		soft.setInfo(info);
		so.save(soft);
		response.sendRedirect("http://localhost:8080/WEB/chahua3265/index.jsp");
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		String fullname=request.getParameter("fullname");
		String info=request.getParameter("phone");
		System.out.print(fullname);
		
		Software soft=new Software();
		soft.setDate(new Date(0));
		soft.setName(fullname);
		soft.setInfo(info);
		new SoftwareDAO().save(soft);
		response.sendRedirect("http://localhost:8080/WEB/index.jsp");
		
	}

	

}
