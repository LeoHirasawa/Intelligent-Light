package model;

import java.util.Date;

/**
 * Software entity. @author MyEclipse Persistence Tools
 */
public class Software extends AbstractSoftware implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Software() {
	}

	/** minimal constructor */
	public Software(String name) {
		super(name);
	}

	/** full constructor */
	public Software(String name, String info, Date date) {
		super(name, info, date);
	}

}
