package model;

import java.util.Date;

/**
 * AbstractSoftware entity provides the base persistence definition of the
 * Software entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractSoftware implements java.io.Serializable {

	// Fields

	private String name;
	private String info;
	private Date date;

	// Constructors

	/** default constructor */
	public AbstractSoftware() {
	}

	/** minimal constructor */
	public AbstractSoftware(String name) {
		this.name = name;
	}

	/** full constructor */
	public AbstractSoftware(String name, String info, Date date) {
		this.name = name;
		this.info = info;
		this.date = date;
	}

	// Property accessors

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInfo() {
		return this.info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}