package model;

/**
 * Id entity. @author MyEclipse Persistence Tools
 */
public class Id extends AbstractId implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Id() {
	}

	/** minimal constructor */
	public Id(String id) {
		super(id);
	}

	/** full constructor */
	public Id(String id, String rank) {
		super(id, rank);
	}

}
