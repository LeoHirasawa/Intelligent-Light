package model;

/**
 * AbstractId entity provides the base persistence definition of the Id entity. @author
 * MyEclipse Persistence Tools
 */

public abstract class AbstractId implements java.io.Serializable {

	// Fields

	private String id;
	private String rank;

	// Constructors

	/** default constructor */
	public AbstractId() {
	}

	/** minimal constructor */
	public AbstractId(String id) {
		this.id = id;
	}

	/** full constructor */
	public AbstractId(String id, String rank) {
		this.id = id;
		this.rank = rank;
	}

	// Property accessors

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRank() {
		return this.rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

}